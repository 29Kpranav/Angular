Adds the npm package for a published library to your workspace, and configures
the project in the current working directory to use that library, as specified by the library's schematic.
For example, adding `@angular/pwa` configures your project for PWA support:

```bash
ng add @angular/pwa
```
